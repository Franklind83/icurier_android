package com.dev.todos.Util;

public class Keys {
    public static final String productOverview="productOverview";
    public static final String forgetPassword="forgetPassword";
    public static final String toolBarAct="toolBarAct";
    public static final String addItem="toolBarAct";
    public static final String forgetPass="forgetPass";
    public static final String active="active";
    public static final String transit="transit";
    public static final String oderType="oderType";
    public static final String userstatus ="userstatus";

    /*parameter*/

    public static final String travel_date="travel_date";
    public static final String email="email";
    public static final String password="password";
    public static final String token_from="token_from";
    public static final String user_token="user_token";
    public static final String name="name";
    public static final String name_account_holder="name_account_holder";
    public static final String mobile="mobile";
    public static final String dial_code="dial_code";
    public static final String country="country";
    public static final String image="image";
    public static final String old_password="old_password";
    public static final String new_password="new_password";
    public static final String post_string="post_string";
    public static final String order_status="order_status";
    public static final String order_id="order_id";
    public static final String current_date="current_date";
    public static final String total_order_price="total_order_price";
    public static String traveller_id="traveller_id";
    public static final String product_list="product_list";
    public static final String article_name="article_name";
    public static final String article_comment="article_comment";
    public static final String buy_item_link="buy_item_link";
    public static final String item_price="item_price";
    public static final String item_quantity="item_quantity";
    public static final String location_from="location_from";
    public static final String location_from_city="location_from_city";
    public static final String location_from_state="location_from_state";
    public static final String location_from_country="location_from_country";
    public static final String location_to_city="location_to_city";
    public static final String location_to_state="location_to_state";
    public static final String location_to_country="location_to_country";

    public static final String login_from="login_from";
    public static final String location_to="location_to";
    public static final String delivery_deadline="delivery_deadline";
    public static final String delivery_reward="delivery_reward";
    public static final String created_date="created_date";
    public static final String created_time="created_time";
    public static final String product_image_list="product_image_list";
    public static final String status="status";
    public static final String product_id="product_id";
    public static String trip_id="trip_id";
    public static final String delivery_from="delivery_from";
    public static final String delivery_to="delivery_to";
    public static final String delivery_date="delivery_date";
    public static final String delivered_to="delivered_to";
    public static final String delivered_image="delivered_image";
    public static final String delivered_person_doc_no="delivered_person_doc_no";
    public static final String reward="reward";
    public static final String shipping_cost="shipping_cost";
    public static final String taxes_fees="taxes_fees";
    public static final String locationFrom="locationFrom";
    public static final String locationTo="locationTo";
    public static final String date="date";
    public static final String device="device";
    public static final String social_id="social_id";

    public static final String firebase_token="reward";
    public static final String isFromMyOrder="isFromMyOrder";
    public static final String bringProduct="bringProduct";
    public static final String order_offer_status="order_offer_status";
    public static final String offer_order_id="offer_order_id";
    public static final String purchase_id="purchase_id";
    public static final String images_list="images_list";
    public static final String is_paypal="is_paypal";

    public static final String identity_card="identity_card";
    public static final String account_number="account_number";
    public static final String bank="bank";
    public static final String user1_id="user1_id";
    public static final String user2_id="user2_id";
    public static final String message="message";
    public static final String message_from="message_from";
    public static final String time="time";
    public static final String purchase_date_="purchase_date";
    public static final String delivery_id="delivery_id";
    public static final String latfrom="location_from_lat";
    public static final String longfrom="location_from_lng";
    public static final String latto="location_to_lat";
    public static final String longto="location_to_lng";






    /*parameter*/

    public static final String status_succes="1";
    public static final String user_id="user_id";
    public static final String isLogin="isLogin";
    public static final String productName="productName";
    public static final String articleComment="articleComment";
    public static final String productLink="productLink";
    public static final String qunt="qunt";
    public static final String price="price";
    public static final String image1="image1";
    public static final String image2="image2";
    public static final String image3="image3";
    public static final String image4="image4";
    public static final String profileImage="profileImage";
    public static final String noOfOrder="noOfOrder";
    public static final String imageList="imageList";
    public static final String isFromUpdate="isFromUpdate";
    public static final String bundle="bundle";
    public static final String imageUri1="imageUri1";
    public static final String imagePath1="imagePath1";
    public static final String imageUri2="imageUri2";
    public static final String imagePath2="imagePath2";
    public static final String imageUri3="imageUri3";
    public static final String imagePath3="imagePath3";
    public static final String imageUri4="imageUri4";
    public static final String imagePath4="imagePath4";

    public static final String nameOrderManage="nameOrderManage";
    public static final String imageOrderManage="nameOrderManage";
    public static final String productInorder="productInorder";
    public static final String isFromIamTravller="productInorder";


}
