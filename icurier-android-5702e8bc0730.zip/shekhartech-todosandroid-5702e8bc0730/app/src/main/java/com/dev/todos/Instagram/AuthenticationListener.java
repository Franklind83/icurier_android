package com.dev.todos.Instagram;

public interface AuthenticationListener {
    void onTokenReceived(String auth_token);
}
