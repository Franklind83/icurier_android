package com.dev.todos.Util;

public class OrderDelivered {
    public static String selectedDate;
    public static String image;
    public static String orderId;
    public static String documentNumber;
    public static String receiverName;
    public static String deliveryDate;
    public static String delivery_id;
    public static boolean isOrderDeliverd = false;
}
