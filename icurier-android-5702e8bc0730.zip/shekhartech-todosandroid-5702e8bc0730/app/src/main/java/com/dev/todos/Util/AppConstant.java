package com.dev.todos.Util;

public class AppConstant {
    public static String RefType ="";
    public static final String USERID = "userid";
    public static final String IS_LOGIN = "is_login";
    public static final String TOKEN = "token";
    public static final String SOCIALLOGIN = "socaillogin";
    public static final String APPLANGUAGE = "applanguage";
    public static final String lang_val= "false";

    public static final String USERNAME = "username";
    public static final String USEREMAIL = "useremail";
    public static String PROFILEIMAGE = "profileimage";
    public static String OFFERSTATUS = "offerstatus";
}
