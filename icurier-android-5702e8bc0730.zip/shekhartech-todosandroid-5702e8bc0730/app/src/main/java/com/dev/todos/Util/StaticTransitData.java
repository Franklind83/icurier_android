package com.dev.todos.Util;


import java.util.List;

public class StaticTransitData {
    public static String offerStatus="";
    public static String fromWhom;
    public static String TravelFrom="";
    public static String TravelTo="";
    public static String UserName;
    public static String Reward;
    public static String TotalPrice;
    public static String NoOfProducts;
    public static List<String> imagelist;
    public static String DeliveryDate;
    public static String OrderOnDate;
    public static String ProfileImage;

 /*   public static List<String> getImagelist() {
        return imagelist;
    }

    public static void setImagelist(List<String> imagelist) {
        StaticTransitData.imagelist = imagelist;
    }

    public static String getUserName() {
        return UserName;
    }

    public static void setUserName(String userName) {
        UserName = userName;
    }

    public static String getReward() {
        return Reward;
    }

    public static void setReward(String reward) {
        Reward = reward;
    }

    public static String getTotalPrice() {
        return TotalPrice;
    }

    public static void setTotalPrice(String totalPrice) {
        TotalPrice = totalPrice;
    }

    public static String getNoOfProducts() {
        return NoOfProducts;
    }

    public static void setNoOfProducts(String noOfProducts) {
        NoOfProducts = noOfProducts;
    }

    public static String getProfileImage() {
        return ProfileImage;
    }

    public static void setProfileImage(String profileImage) {
        ProfileImage = profileImage;
    }

    public static String ProfileImage;

    public static String getTravelFrom() {
        return TravelFrom;
    }

    public static void setTravelFrom(String travelFrom) {
        TravelFrom = travelFrom;
    }

    public static String getTravelTo() {
        return TravelTo;
    }

    public static void setTravelTo(String travelTo) {
        TravelTo = travelTo;
    }

    public static String getOrderOnDate() {
        return OrderOnDate;
    }

    public static void setOrderOnDate(String orderOnDate) {
        OrderOnDate = orderOnDate;
    }

    public static String getDeliveryDate() {
        return DeliveryDate;
    }

    public static void setDeliveryDate(String deliveryDate) {
        DeliveryDate = deliveryDate;
    }

*/



}
